var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["96089d62-d9a8-4059-8b39-49d0c0627772","11da05ef-925b-412c-ad7c-3c10d20b1771","37595709-ca01-49f6-ba83-b992ffd10240","e6d10693-20e7-44f1-9bcd-fe9f32b82953","5463fae6-eeee-48d0-87a7-ea066f0baf55","faebf18f-7e8b-452b-89f2-36fc5ff20c25","0404d3a5-1589-46cd-9fe8-fba582b920c5","a39ca973-7a8b-4298-9bb3-68a6364f6151","53752a9a-be97-4c3b-9bc1-14dd07d8b8b0","7d29c3e7-df78-4e60-ad01-5bf053485a9b"],"propsByKey":{"96089d62-d9a8-4059-8b39-49d0c0627772":{"name":"ground_stone_1","sourceUrl":null,"frameSize":{"x":380,"y":95},"frameCount":1,"looping":true,"frameDelay":12,"version":"OyhFJ33Z.6oCb4QSh4wOj2YjbjFsMJC7","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":380,"y":95},"rootRelativePath":"assets/96089d62-d9a8-4059-8b39-49d0c0627772.png"},"11da05ef-925b-412c-ad7c-3c10d20b1771":{"name":"press","sourceUrl":"assets/v3/animations/kWdJGtgMsh403EZlbJwepV4zhU5kNbHzX5e0QUCwerQ/11da05ef-925b-412c-ad7c-3c10d20b1771.png","frameSize":{"x":812,"y":148},"frameCount":1,"looping":true,"frameDelay":4,"version":"m_qeUW3H7xkEPf9ZQQzVMXqt2vV3typK","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":812,"y":148},"rootRelativePath":"assets/v3/animations/kWdJGtgMsh403EZlbJwepV4zhU5kNbHzX5e0QUCwerQ/11da05ef-925b-412c-ad7c-3c10d20b1771.png"},"37595709-ca01-49f6-ba83-b992ffd10240":{"name":"press-no","sourceUrl":"assets/api/v1/animation-library/mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz/category_backgrounds/blank.png","frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":4,"version":"mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/api/v1/animation-library/mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz/category_backgrounds/blank.png"},"e6d10693-20e7-44f1-9bcd-fe9f32b82953":{"name":"win-no","sourceUrl":"assets/api/v1/animation-library/mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz/category_backgrounds/blank.png","frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":4,"version":"mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/api/v1/animation-library/mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz/category_backgrounds/blank.png"},"5463fae6-eeee-48d0-87a7-ea066f0baf55":{"name":"win","sourceUrl":null,"frameSize":{"x":1000,"y":1000},"frameCount":1,"looping":true,"frameDelay":12,"version":"AZuvbxhce.7VGBXBqCvv.tGjKP4rK5lH","loadedFromSource":true,"saved":true,"sourceSize":{"x":1000,"y":1000},"rootRelativePath":"assets/5463fae6-eeee-48d0-87a7-ea066f0baf55.png"},"faebf18f-7e8b-452b-89f2-36fc5ff20c25":{"name":"lose","sourceUrl":null,"frameSize":{"x":1000,"y":1000},"frameCount":1,"looping":true,"frameDelay":12,"version":"cgxgxJYnFhMvXxfmVo3hHb0dpRSM5wWu","loadedFromSource":true,"saved":true,"sourceSize":{"x":1000,"y":1000},"rootRelativePath":"assets/faebf18f-7e8b-452b-89f2-36fc5ff20c25.png"},"0404d3a5-1589-46cd-9fe8-fba582b920c5":{"name":"white","sourceUrl":null,"frameSize":{"x":128,"y":128},"frameCount":1,"looping":true,"frameDelay":12,"version":"oN3WYU15bUvLVAbCPKhrTzJewWQygBQn","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":128},"rootRelativePath":"assets/0404d3a5-1589-46cd-9fe8-fba582b920c5.png"},"a39ca973-7a8b-4298-9bb3-68a6364f6151":{"name":"red","sourceUrl":null,"frameSize":{"x":128,"y":128},"frameCount":1,"looping":true,"frameDelay":12,"version":"eMTsKoVKc2sIeGmQUduIIrvq9n5uCJ7W","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":128},"rootRelativePath":"assets/a39ca973-7a8b-4298-9bb3-68a6364f6151.png"},"53752a9a-be97-4c3b-9bc1-14dd07d8b8b0":{"name":"pelota","sourceUrl":null,"frameSize":{"x":33,"y":33},"frameCount":1,"looping":true,"frameDelay":12,"version":"FJ2kds6oe3TcvBj2.ydSukjwtpMzyB9o","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":33,"y":33},"rootRelativePath":"assets/53752a9a-be97-4c3b-9bc1-14dd07d8b8b0.png"},"7d29c3e7-df78-4e60-ad01-5bf053485a9b":{"name":"explotion","sourceUrl":null,"frameSize":{"x":25,"y":25},"frameCount":8,"looping":true,"frameDelay":3,"version":"XSA8qvctRscLrEoYUjWNk0IH6C4TPrHe","loadedFromSource":true,"saved":true,"sourceSize":{"x":75,"y":75},"rootRelativePath":"assets/7d29c3e7-df78-4e60-ad01-5bf053485a9b.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//bricks
var bricks = createSprite(50, 100, 40, 40);
bricks.setAnimation("white");
bricks.scale=0.39
var bricks2 = createSprite(100, 100, 40, 40);
bricks2.setAnimation("red");
bricks2.scale=0.39
var bricks3 = createSprite(150, 100, 40, 40);
bricks3.setAnimation("white");
bricks3.scale=0.39
var bricks4 = createSprite(200, 100, 40, 40);
bricks4.setAnimation("red");
bricks4.scale=0.39
var bricks5 = createSprite(250, 100, 40, 40);
bricks5.setAnimation("white");
bricks5.scale=0.39
var bricks6 = createSprite(300, 100, 40, 40);
bricks6.setAnimation("red");
bricks6.scale=0.39
var bricks7 = createSprite(350, 100, 40, 40);
bricks7.setAnimation("white");
bricks7.scale=0.39
var bricks8 = createSprite(50, 150, 40, 40);
bricks8.setAnimation("red");
bricks8.scale=0.39
var bricks10 = createSprite(100, 150, 40, 40);
bricks10.setAnimation("white");
bricks10.scale=0.39
var bricks11 = createSprite(150, 150, 40, 40);
bricks11.setAnimation("red");
bricks11.scale=0.39
var bricks12 = createSprite(200, 150, 40, 40);
bricks12.setAnimation("white");
bricks12.scale=0.39
var bricks13 = createSprite(250, 150, 40, 40);
bricks13.setAnimation("red");
bricks13.scale=0.39
var bricks14 = createSprite(300, 150, 40, 40);
bricks14.setAnimation("white");
bricks14.scale=0.39
var bricks15 = createSprite(350, 150, 40, 40);
bricks15.setAnimation("red");
bricks15.scale=0.39
//elementos del jugador
var press = createSprite(200, 50, 10, 10);
press.scale=0.2;
press.setAnimation("press");
var paleta = createSprite(200, 350, 10, 70);
var pelota = createSprite(200, 200, 10, 10);
var pelota2 = createSprite(25, 385, 10, 10);
var win = createSprite(200, 200, 10, 10);
win.scale=0.5;
win.setAnimation("win-no");
paleta.scale=0.2;
paleta.setAnimation("ground_stone_1");
pelota.scale=1;
pelota.setAnimation("pelota");
pelota2.scale=1;
pelota2.setAnimation("pelota");
var puntos = 0;
var vidas = 3;
var estado="inicio";


//fondo
playSound("assets/category_background/eerie_beginnings.mp3", false);
function draw() {
  background("black");
  if (pelota.isTouching(paleta)) {
playSound("assets/category_tap/vibrant_ui_mouse_click_2.mp3", false);
}
//points
textSize(50);
fill("white");
text("points: " + puntos, 50, 250);
textSize(50);
fill("white");
text("x " + vidas, 50, 400);
//funciones de la pelota y la paleta
createEdgeSprites()
pelota.bounceOff(topEdge)
pelota.bounceOff(rightEdge)
pelota.bounceOff(leftEdge)
pelota.bounceOff(paleta)
paleta.collide(rightEdge)
paleta.collide(leftEdge)


if (estado === "inicio") {
    win.setAnimation("win-no");
  if (keyDown("space")) {
  pelota.velocityY = 2;
  pelota.velocityX = 5;
  press.setAnimation("press-no");
  estado="juego";
  
}
 if (keyDown(LEFT_ARROW)) {
  paleta.velocityX = 0;
  } 
  if (keyDown(RIGHT_ARROW)) {
      paleta.velocityX = 0;
    }
}
if (estado === "juego") {

if (pelota.isTouching(paleta)) {
playSound("assets/category_accent/puzzle_game_accent_silly_02.mp3", false);
}
if (pelota.isTouching(bottomEdge)) {
pelota.x=200;
pelota.y=200;
  pelota.velocityY = 2;
  pelota.velocityX = 5;
    vidas -=1;
  playSound("assets/category_explosion/air_explode_bonus_6.mp3", false);


}
  if (keyDown(LEFT_ARROW)) {
  paleta.velocityX = -5;
  } 
  if (keyDown(RIGHT_ARROW)) {
      paleta.velocityX = 5;
    }
     if (puntos===14) {
  win.setAnimation("win");
    estado="fin";
      }  
 if (vidas===0) {
  win.setAnimation("lose");
    estado="fin";

}

if (estado === "fin") {
      pelota.velocityY = 0;
  pelota.velocityX = 0;
  if (keyDown("space")) {
  pelota.velocityY = 2;
  pelota.velocityX = 5;
  press.setAnimation("press-no");
    win.setAnimatio("win-no");
  estado="juego";
  puntos=0;
  } 
}
}
//destruccion de los ladrillos
if (pelota.isTouching(bricks)) {
      pelota.bounceOff(bricks)
      bricks.destroy()
  puntos +=1;
      

      playSound("assets/category_explosion/8bit_explosion.mp3" ,false);

    }
    if (pelota.isTouching(bricks2)) {
         pelota.bounceOff(bricks2)
      bricks2.destroy()
    puntos +=1;
      

       playSound("assets/category_explosion/8bit_explosion.mp3" ,false);
    }
    if (pelota.isTouching(bricks3)) {
     pelota.bounceOff(bricks3)
      bricks3.destroy()
      puntos +=1;
      

      playSound("assets/category_explosion/8bit_explosion.mp3" ,false);
    }
    if (pelota.isTouching(bricks4)) {
     pelota.bounceOff(bricks4)
      bricks4.destroy()
  puntos +=1;
      
       playSound("assets/category_explosion/8bit_explosion.mp3" ,false);
    }
     
     
     
     
     
    if (pelota.isTouching(bricks5)) {
      pelota.bounceOff(bricks5)
      bricks5.destroy()     
     puntos +=1;
      

      playSound("assets/category_explosion/8bit_explosion.mp3" ,false);

    }
    if (pelota.isTouching(bricks6)) {
         pelota.bounceOff(bricks6)
      bricks6.destroy()
  puntos +=1;
      

       playSound("assets/category_explosion/8bit_explosion.mp3" ,false);
    }
    if (pelota.isTouching(bricks7)) {
     pelota.bounceOff(bricks7)
      bricks7.destroy()
  puntos +=1;
      

      playSound("assets/category_explosion/8bit_explosion.mp3" ,false);
    }
    if (pelota.isTouching(bricks8)) {
     pelota.bounceOff(bricks8)
      bricks8.destroy()
   puntos +=1;
      
       playSound("assets/category_explosion/8bit_explosion.mp3" ,false);
    }
    
    
    
    if (pelota.isTouching(bricks10)) {
      pelota.bounceOff(bricks10)
      bricks10.destroy()     
  puntos +=1;
      

      playSound("assets/category_explosion/8bit_explosion.mp3" ,false);

    }
    if (pelota.isTouching(bricks11)) {
         pelota.bounceOff(bricks11)
      bricks11.destroy()
  puntos +=1;
      

       playSound("assets/category_explosion/8bit_explosion.mp3" ,false);
    }
    if (pelota.isTouching(bricks12)) {
     pelota.bounceOff(bricks12)
      bricks12.destroy()
  puntos +=1;
      

      playSound("assets/category_explosion/8bit_explosion.mp3" ,false);
    }
    if (pelota.isTouching(bricks13)) {
     pelota.bounceOff(bricks13)
      bricks13.destroy()
  puntos +=1;
      
       playSound("assets/category_explosion/8bit_explosion.mp3" ,false);
    }
    
    
    
    
    
    if (pelota.isTouching(bricks14)) {
      pelota.bounceOff(bricks14)
      bricks14.destroy()     
  puntos +=1;
      

      playSound("assets/category_explosion/8bit_explosion.mp3" ,false);

    }
    if (pelota.isTouching(bricks15)) {
         pelota.bounceOff(bricks15)
      bricks15.destroy()
  puntos +=1;
      

       playSound("assets/category_explosion/8bit_explosion.mp3" ,false);
    }

  
//stop
drawSprites();

}
 

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
